'use strict';

function psytest ($mass, $scheme, $id_student, $id_test) {
	let _this = this;
	_this.index = 1;
	_this.answers = [];

	this.build = function () {
		let obj = document.querySelector('body > #test');
		obj.querySelector('li > p').innerHTML = _this.index+") "+$mass[_this.index]['question'];
		obj.querySelectorAll('li > label > span')[0].innerHTML = $mass[_this.index]['a'];
		obj.querySelectorAll('li > label > input')[0].checked = false;
		obj.querySelectorAll('li > label > span')[1].innerHTML = $mass[_this.index]['b'];
		obj.querySelectorAll('li > label > input')[1].checked = false;
		let listbox = document.querySelector('body > #listbox');
		listbox.innerHTML = '';		
		for (let i = 1; i<=$mass.length; i++) {
			let option = document.createElement('option');
			option.value = i;
			option.textContent = 'Вопрос №'+i;
			if (i == _this.index) {
				option.selected = true;
			}
			listbox.appendChild(option);
		}
		if (typeof(_this.answers[_this.index]) !== "undefined") {
			obj.querySelectorAll('li > label > input')[_this.answers[_this.index]].checked = true;
		}

	}

	this.next = function () {
		if ($mass['length'] > _this.index) {_this.index = _this.index + 1;} else {
			_this.index = 1;
		}
	_this.build(_this.index);
	}

	this.back = function () {
		if (1 >= _this.index) {_this.index = $mass['length'];} else {
			_this.index = _this.index - 1;
		}
	_this.build(_this.index);
	}

	this.send = function ($itog) {
		fetch('/moodle/mod/new_test_type/result.php',
		{method : 'post', 
		headers : {
			'Content-type' : 'application/x-www-form-urlencoded; charset=UTF-8'
		},
		body : 'result='+JSON.stringify($itog)+'&id_user='+$id_student})
	  		.then(function(response) {
	   				 return response.text();
	   		})
			.then((data) => {
		  		if (data == 'true') {window.location.href = 'http://'+document.location.host+"/moodle/mod/new_test_type/end_test.php?id_student="+$id_student+'&id_test='+$id_test;}
		  		else {alert('Возникла непредвиденная ошибка!');}
	  		});
	}

	_this.build();

	document.querySelector('body > #first').addEventListener ('click', function () {
		_this.index = 1;
		_this.build();
	});

	document.querySelector('body > #back').addEventListener ('click', function () {
		_this.back();
	});

	document.querySelector('body > #next').addEventListener ('click', function () {
		_this.next();
	});

	document.querySelector('body > #listbox').addEventListener('change', function ()  {
		_this.index = this.options[this.selectedIndex].value;
		_this.build();
	})

	document.querySelector('body > #end').addEventListener ('click', function () {
		_this.index = $mass['length'];
		_this.build();
	});

	document.querySelectorAll('body > #test > li > label')[0].addEventListener ('change', function () {
		_this.answers[_this.index] = 0;
	});

	document.querySelectorAll('body > #test > li > label')[1].addEventListener ('change', function () {
		_this.answers[_this.index] = 1;
	});

	document.querySelector('body > #stop').addEventListener ('click', function () {
		let $itog = {'1' : 0, '2' : 0, '3' : 0, '4' : 0, '5' : 0, '6' : 0}, $i = 1, $j = 1;
		do {
			if (_this.answers[$i] == 0) {
				$itog[$scheme[$j]['id_category']] = $itog[$scheme[$j]['id_category']] + 1;
			}

			if (_this.answers[$i] == 1) {
				$itog[$scheme[$j+1]['id_category']] = $itog[$scheme[$j+1]['id_category']] + 1;
			}
			$i = $i + 1;
			$j = $j + 2;
		} while ($i <= $mass['length']);
		_this.send($itog);
	});
}