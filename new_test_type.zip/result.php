<?php
require_once("../../config.php");

global $DB;

$result = json_decode($_POST['result'], true);
$id_user = $_POST['id_user'];
arsort($result, SORT_STRING | SORT_FLAG_CASE | SORT_NATURAL);

$category = $DB->get_records_sql('select * from mdl_psytest_category');

$tmp = '';
foreach ($result as $key => $value) {
	$tmp = $tmp.$category[$key]->category.' - '.$value.'<br/>';
}

if ((isset($id_user)) && (isset($tmp))) {
$records['id_test'] = 1;
$records['id_user'] = $id_user;
$records['result'] = $tmp;
$records['date_test'] = date("Y-m-d H:i:s");

$lastid = $DB->insert_record('psytest_result', $records, false);
}

if (isset($lastid)) {echo "true";} else 
{echo "false";}