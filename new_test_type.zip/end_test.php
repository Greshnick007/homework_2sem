<?php
require_once("../../config.php");

global $DB;

$id_user = $_GET['id_student'];
$id_test = $_GET['id_test'];
$result = $DB->get_records_sql('select * from mdl_psytest_result where id_test = ? and id_user = ? ORDER BY date_test DESC limit 1', array(strval($id_test), strval($id_user)));
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="psytest.css"/>
</head>
<body>
<div id="result_test">
<h3>Результат вашего тестирования:</h3>
<p>Склонности к сферам расположены в порядке убывания</p>
<?php 
	foreach ($result as $item) {
		echo $item->result.'<br/>';
	}
?>
</div>
</body>
</html>