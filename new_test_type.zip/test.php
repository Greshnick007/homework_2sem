<?php
require_once("../../config.php");

global $DB;
$id_test = $_GET['id_test'];
$question = $DB->get_records_sql('select * from mdl_psytest_question where id_test = ?', array($id_test));
$question['length'] = count($question);
$scheme = $DB->get_records_sql('select * from mdl_psytest_scheme where id_test = ?', array($id_test));
$scheme['length'] = count($scheme);
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="psytest.css"/>
</head>
<body>
	<select id="listbox"></select>
	<button id="first">Начало</button>
	<button id="back">Назад</button>
	<button id="next">Вперед</button>
	<button id="end">Конец</button>
	<button id="stop">Завершить</button>
	<ul id="test">
		<li>
			<p></p>
			<label><input type="radio" name="answer" value="a"/><span></span></label>
			<label><input type="radio" name="answer" value="b"/><span></span></label>
		</li>
	</ul>
</body>
	<script src='<?php echo $CFG->wwwroot; ?>/mod/new_test_type/test.js'></script>
	<script>{
		let question = <?php echo json_encode($question); ?>,
			scheme = <?php echo json_encode($scheme); ?>,
			id_student = <?php echo $USER->id; ?>;
		let test = new psytest(question, scheme, id_student, 1);
		}</script>
</html>